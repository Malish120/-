// Константы игры
const MAZE_SIZE = 8;
const MAX_HEALTH = 100;
const FOOD_HEAL_AMOUNT = 20;
const DOOR = 'exit'; // Константа для двери

// Конфигурация уровней
const LEVELS_CONFIG = [
    { level: 1, food: 3, walls: 10, healthInterval: 2000 },
    { level: 2, food: 5, walls: 15, healthInterval: 1800 },
    { level: 3, food: 7, walls: 20, healthInterval: 1500 },
    { level: 4, food: 9, walls: 22, healthInterval: 1200 },
    { level: 5, food: 11, walls: 25, healthInterval: 1000 }
];

// Состояние игры
const gameState = {
    gameActive: false,
    currentLevel: 1,
    catPosition: { x: 1, y: 1 },
    exitPosition: { x: MAZE_SIZE - 2, y: MAZE_SIZE - 2 },
    maze: [],
    foodPositions: [],
    foodCollected: 0,
    health: MAX_HEALTH,
    healthTimer: null,
    swipeStart: null,
    exitReachable: false // Флаг доступности выхода
};

// Элементы DOM
const mazeElement = document.getElementById('maze');
const levelElement = document.getElementById('level');
const foodCounterElement = document.getElementById('food-counter');
const foodTargetElement = document.getElementById('food-target');
const healthBarElement = document.getElementById('health-bar');
const messageElement = document.getElementById('message');
const messageTitleElement = document.getElementById('message-title');
const messageTextElement = document.getElementById('message-text');
const messageBtnElement = document.getElementById('message-btn');

// Инициализация игры
function initGame() {
    gameState.gameActive = true;
    gameState.currentLevel = 1;
    gameState.foodCollected = 0;
    gameState.health = MAX_HEALTH;
    gameState.exitReachable = false;
    
    // Настройка первого уровня
    const levelConfig = LEVELS_CONFIG[0];
    levelElement.textContent = gameState.currentLevel;
    foodTargetElement.textContent = levelConfig.food;
    
    // Генерация лабиринта
    generateMaze();
    renderMaze();
    updateUI();
    
    // Запуск таймера здоровья
    gameState.healthTimer = setInterval(decreaseHealth, levelConfig.healthInterval);
    
    // Назначение обработчиков событий
    document.getElementById('up').addEventListener('click', () => moveCat(0, -1));
    document.getElementById('left').addEventListener('click', () => moveCat(-1, 0));
    document.getElementById('right').addEventListener('click', () => moveCat(1, 0));
    document.getElementById('down').addEventListener('click', () => moveCat(0, 1));
    
    // Обработчики свайпов
    mazeElement.addEventListener('touchstart', handleTouchStart, false);
    mazeElement.addEventListener('touchmove', handleTouchMove, false);
    
    messageBtnElement.addEventListener('click', hideMessage);
    
    // Показываем начальное сообщение
    showMessage('Уровень 1', 'Соберите всю еду и найдите выход!');
    setTimeout(() => hideMessage(), 2500);
}

// Генерация лабиринта
function generateMaze() {
    const levelConfig = LEVELS_CONFIG.find(config => config.level === gameState.currentLevel);
    
    // Очищаем предыдущий лабиринт
    gameState.maze = [];
    gameState.foodPositions = [];
    
    // Создаем пустой лабиринт
    for (let y = 0; y < MAZE_SIZE; y++) {
        const row = [];
        for (let x = 0; x < MAZE_SIZE; x++) {
            row.push('empty');
        }
        gameState.maze.push(row);
    }
    
    // Добавляем стены
    addWalls(levelConfig.walls);
    
    // Устанавливаем позицию кота
    gameState.catPosition = { x: 1, y: 1 };
    gameState.maze[gameState.catPosition.y][gameState.catPosition.x] = 'cat';
    
    // Устанавливаем выход (дверь)
    gameState.exitPosition = { x: MAZE_SIZE - 2, y: MAZE_SIZE - 2 };
    gameState.maze[gameState.exitPosition.y][gameState.exitPosition.x] = DOOR;
    
    // Добавляем еду
    addFood(levelConfig.food);
    
    // Проверка доступности пути
    ensurePathToExit();
}

// Добавление стен
function addWalls(wallCount) {
    let wallsAdded = 0;
    while (wallsAdded < wallCount) {
        const x = Math.floor(Math.random() * MAZE_SIZE);
        const y = Math.floor(Math.random() * MAZE_SIZE);
        
        // Не ставим стены на старт, выход или там, где уже стена
        if ((x === 1 && y === 1) || 
            (x === MAZE_SIZE - 2 && y === MAZE_SIZE - 2) || 
            gameState.maze[y][x] === 'wall') {
            continue;
        }
        
        gameState.maze[y][x] = 'wall';
        wallsAdded++;
    }
}

// Проверка, находится ли клетка рядом с выходом
function isNearExit(x, y) {
    const exit = gameState.exitPosition;
    // Проверяем все 8 направлений (включая диагонали)
    const directions = [
        {dx: -1, dy: -1}, {dx: 0, dy: -1}, {dx: 1, dy: -1},
        {dx: -1, dy: 0},                   {dx: 1, dy: 0},
        {dx: -1, dy: 1},  {dx: 0, dy: 1},  {dx: 1, dy: 1}
    ];
    
    for (const dir of directions) {
        const nx = exit.x + dir.dx;
        const ny = exit.y + dir.dy;
        if (x === nx && y === ny) {
            return true;
        }
    }
    return false;
}

// Добавление еды
function addFood(foodCount) {
    let foodAdded = 0;
    while (foodAdded < foodCount) {
        const x = Math.floor(Math.random() * MAZE_SIZE);
        const y = Math.floor(Math.random() * MAZE_SIZE);
        
        // Еда не должна появляться:
        // 1. На стенах
        // 2. На стартовой позиции
        // 3. На выходе (двери)
        // 4. На других едах
        // 5. В клетках рядом с выходом
        if (gameState.maze[y][x] !== 'empty' || 
            (x === 1 && y === 1) || 
            (x === gameState.exitPosition.x && y === gameState.exitPosition.y) ||
            isNearExit(x, y)) {
            continue;
        }
        
        gameState.maze[y][x] = 'food';
        gameState.foodPositions.push({ x, y });
        foodAdded++;
    }
}

// Обеспечение пути к выходу
function ensurePathToExit() {
    // Создаем копию лабиринта для проверки
    const mazeCopy = JSON.parse(JSON.stringify(gameState.maze));
    
    // Проверяем, есть ли путь от кота до выхода
    if (!pathExists(mazeCopy, gameState.catPosition, gameState.exitPosition)) {
        // Если пути нет, перегенерируем лабиринт
        generateMaze();
        return;
    }
    
    // Проверяем путь до каждой еды
    for (const food of gameState.foodPositions) {
        if (!pathExists(mazeCopy, gameState.catPosition, food)) {
            // Если до какой-то еды нет пути, перегенерируем лабиринт
            generateMaze();
            return;
        }
    }
}

// Алгоритм поиска пути (BFS)
function pathExists(maze, start, end) {
    const visited = new Set();
    const queue = [start];
    const directions = [
        {dx: 1, dy: 0},  // вправо
        {dx: -1, dy: 0}, // влево
        {dx: 0, dy: 1},  // вниз
        {dx: 0, dy: -1}  // вверх
    ];
    
    while (queue.length > 0) {
        const current = queue.shift();
        const key = `${current.x},${current.y}`;
        
        if (visited.has(key)) continue;
        visited.add(key);
        
        // Проверяем, достигли ли мы цели
        if (current.x === end.x && current.y === end.y) {
            return true;
        }
        
        // Проверяем соседние клетки
        for (const dir of directions) {
            const newX = current.x + dir.dx;
            const newY = current.y + dir.dy;
            
            // Проверяем границы лабиринта
            if (newX < 0 || newX >= MAZE_SIZE || newY < 0 || newY >= MAZE_SIZE) {
                continue;
            }
            
            // Проверяем, не стена ли это и не посещали ли уже
            if (maze[newY][newX] !== 'wall' && !visited.has(`${newX},${newY}`)) {
                queue.push({x: newX, y: newY});
            }
        }
    }
    
    return false;
}

// Отрисовка лабиринта
function renderMaze() {
    mazeElement.innerHTML = '';
    mazeElement.style.gridTemplateColumns = `repeat(${MAZE_SIZE}, 1fr)`;
    
    for (let y = 0; y < MAZE_SIZE; y++) {
        for (let x = 0; x < MAZE_SIZE; x++) {
            const cell = document.createElement('div');
            cell.className = 'cell';
            cell.classList.add(gameState.maze[y][x]); // 'empty', 'wall', 'cat', 'food', 'exit'
            
            mazeElement.appendChild(cell);
        }
    }
}

// Обновление интерфейса
function updateUI() {
    const levelConfig = LEVELS_CONFIG.find(config => config.level === gameState.currentLevel);
    
    // Обновляем отображение уровня
    levelElement.textContent = gameState.currentLevel;
    
    // Обновляем счетчик еды
    foodCounterElement.textContent = gameState.foodCollected;
    foodTargetElement.textContent = levelConfig.food;
    
    // Обновляем здоровье
    healthBarElement.style.width = `${gameState.health}%`;
    
    // Обновляем текст для скринридеров
    const healthValueElement = document.getElementById('health-value');
    if (healthValueElement) {
        healthValueElement.textContent = `${gameState.health}%`;
    }
    
    // Изменяем цвет полоски здоровья
    if (gameState.health > 70) {
        healthBarElement.style.background = 'linear-gradient(90deg, #00ff7f, #7cfc00)';
    } else if (gameState.health > 30) {
        healthBarElement.style.background = 'linear-gradient(90deg, #ffcc70, #ff9900)';
    } else {
        healthBarElement.style.background = 'linear-gradient(90deg, #ff416c, #ff4b2b)';
    }
}

// Перемещение кота
function moveCat(dx, dy) {
    if (!gameState.gameActive) return;
    
    const newX = gameState.catPosition.x + dx;
    const newY = gameState.catPosition.y + dy;
    
    // Проверка на выход за пределы лабиринта
    if (newX < 0 || newX >= MAZE_SIZE || newY < 0 || newY >= MAZE_SIZE) {
        return;
    }
    
    // Проверка на стену
    if (gameState.maze[newY][newX] === 'wall') {
        return;
    }
    
    // Проверка на дверь (выход)
    if (gameState.maze[newY][newX] === DOOR) {
        const levelConfig = LEVELS_CONFIG.find(config => config.level === gameState.currentLevel);
        
        // Проверяем, собрана ли вся еда
        if (gameState.foodCollected >= levelConfig.food) {
            // Разрешаем проход через дверь
            gameState.exitReachable = true;
            passThroughDoor(newX, newY);
        } else {
            // Показываем сообщение, что нужно собрать всю еду
            showMessage('Ещё не всё!', `Соберите всю еду (${levelConfig.food} шт.), чтобы открыть дверь!`, false);
            setTimeout(() => hideMessage(), 2000);
        }
        return;
    }
    
    // Очищаем текущую позицию кота
    gameState.maze[gameState.catPosition.y][gameState.catPosition.x] = 'empty';
    
    // Проверка на еду
    if (gameState.maze[newY][newX] === 'food') {
        gameState.foodCollected++;
        gameState.health = Math.min(MAX_HEALTH, gameState.health + FOOD_HEAL_AMOUNT);
        
        // Удаляем собранную еду
        gameState.foodPositions = gameState.foodPositions.filter(
            pos => !(pos.x === newX && pos.y === newY)
        );
        
        // Создаем эффект падающего котика
        createFallingCatEffect();
    }
    
    // Перемещаем кота
    gameState.catPosition = { x: newX, y: newY };
    gameState.maze[newY][newX] = 'cat';
    
    // Обновляем отображение
    renderMaze();
    updateUI();
}

// Функция прохода через дверь
function passThroughDoor(doorX, doorY) {
    // Очищаем текущую позицию кота
    gameState.maze[gameState.catPosition.y][gameState.catPosition.x] = 'empty';
    
    // Перемещаем кота на позицию двери
    gameState.catPosition = { x: doorX, y: doorY };
    gameState.maze[doorY][doorX] = 'cat'; // Кот проходит через дверь
    
    // Обновляем отображение
    renderMaze();
    updateUI();
    
    // Задержка перед переходом на следующий уровень
    setTimeout(() => {
        nextLevel();
        gameState.exitReachable = false; // Сбрасываем флаг после перехода
    }, 500);
}

// Создание эффекта падающих котиков
function createFallingCatEffect() {
    const gameContainer = document.querySelector('.game-container');
    for (let i = 0; i < 3; i++) {
        const cat = document.createElement('div');
        cat.className = 'falling-cat';
        cat.textContent = '🐱';
        cat.style.left = `${Math.random() * 100}%`;
        cat.style.animationDuration = `${Math.random() * 3 + 2}s`;
        gameContainer.appendChild(cat);
        
        // Удаляем элемент после завершения анимации
        setTimeout(() => {
            cat.remove();
        }, 5000);
    }
}

// Уменьшение здоровья
function decreaseHealth() {
    if (!gameState.gameActive) return;
    
    gameState.health -= 5;
    updateUI();
    
    if (gameState.health <= 0) {
        gameState.health = 0;
        gameOver();
    }
}

// Переход на следующий уровень
function nextLevel() {
    // Проверяем, не последний ли это уровень
    if (gameState.currentLevel >= LEVELS_CONFIG.length) {
        winGame();
        return;
    }
    
    // Увеличиваем уровень
    gameState.currentLevel++;
    gameState.foodCollected = 0;
    gameState.health = MAX_HEALTH;
    
    const levelConfig = LEVELS_CONFIG.find(config => config.level === gameState.currentLevel);
    if (!levelConfig) return;
    
    // Обновляем UI с новым уровнем
    levelElement.textContent = gameState.currentLevel;
    foodTargetElement.textContent = levelConfig.food;
    
    // Обновляем таймер здоровья для нового уровня
    clearInterval(gameState.healthTimer);
    gameState.healthTimer = setInterval(
        decreaseHealth, 
        levelConfig.healthInterval
    );
    
    // Генерируем новый лабиринт
    generateMaze();
    renderMaze();
    updateUI();
    
    // Показываем сообщение о новом уровне
    showMessage(`Уровень ${gameState.currentLevel}`, 
               `Лабиринт стал сложнее! Собери ${levelConfig.food} еды для перехода.`);
}

// Победа в игре
function winGame() {
    gameState.gameActive = false;
    clearInterval(gameState.healthTimer);
    showMessage('Победа!', 'Ты прошел все уровни! Мур-мяу!', true, true);
}

// Конец игры
function gameOver() {
    gameState.gameActive = false;
    clearInterval(gameState.healthTimer);
    showMessage('Поражение', 'Кот остался без сил... Попробуй еще раз!', true, true);
}

// Показать сообщение (добавляем параметр showRestart)
function showMessage(title, text, showButton = true, showRestart = false) {
    messageTitleElement.textContent = title;
    messageTextElement.textContent = text;
    messageBtnElement.style.display = showButton ? 'block' : 'none';
    
    // Доступность: показываем сообщение
    messageElement.setAttribute('aria-hidden', 'false');
    
    // Добавляем кнопку перезапуска при проигрыше/победе
    if (showRestart) {
        const restartBtn = document.createElement('button');
        restartBtn.id = 'restart-btn';
        restartBtn.textContent = 'Играть заново';
        restartBtn.addEventListener('click', restartGame);
        messageElement.appendChild(restartBtn);
    }
    
    messageElement.style.display = 'block';
    
    // Фокусируемся на кнопке
    if (showButton) {
        setTimeout(() => {
            messageBtnElement.focus();
        }, 100);
    }
}

// Скрыть сообщение
function hideMessage() {
    // Удаляем кнопку перезапуска, если она есть
    const restartBtn = document.getElementById('restart-btn');
    if (restartBtn) {
        restartBtn.remove();
    }
    
    // Доступность: скрываем сообщение
    messageElement.setAttribute('aria-hidden', 'true');
    messageElement.style.display = 'none';
}

// Перезапуск игры
function restartGame() {
    hideMessage();
    
    // Сброс состояния игры
    gameState.gameActive = false;
    gameState.currentLevel = 1;
    gameState.foodCollected = 0;
    gameState.health = MAX_HEALTH;
    gameState.exitReachable = false;
    
    // Очистка таймеров
    if (gameState.healthTimer) {
        clearInterval(gameState.healthTimer);
        gameState.healthTimer = null;
    }
    
    // Перезапуск игры
    initGame();
}

// Обработка касаний для свайпов
function handleTouchStart(event) {
    const touch = event.touches[0];
    gameState.swipeStart = { x: touch.clientX, y: touch.clientY };
}

function handleTouchMove(event) {
    if (!gameState.swipeStart) return;
    event.preventDefault();
    
    const touch = event.touches[0];
    const dx = touch.clientX - gameState.swipeStart.x;
    const dy = touch.clientY - gameState.swipeStart.y;
    const absDx = Math.abs(dx);
    const absDy = Math.abs(dy);
    
    if (Math.max(absDx, absDy) < 10) return; // мертвая зона
    
    if (absDx > absDy) {
        // Горизонтальный свайп
        if (dx > 0) {
            moveCat(1, 0); // Вправо
        } else {
            moveCat(-1, 0); // Влево
        }
    } else {
        // Вертикальный свайп
        if (dy > 0) {
            moveCat(0, 1); // Вниз
        } else {
            moveCat(0, -1); // Вверх
        }
    }
    
    gameState.swipeStart = null;
}

// Запуск игры при загрузке
window.onload = initGame;